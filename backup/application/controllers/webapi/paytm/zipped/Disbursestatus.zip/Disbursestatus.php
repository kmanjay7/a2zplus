<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Disbursestatus extends CI_Controller{
	
	function __construct() {
         parent::__construct();  
    }



	function index(){

			header("Pragma: no-cache");
			header("Cache-Control: no-cache");
			header("Expires: 0");

		    // following files need to be included
			require_once(APPPATH . "/third_party/PaytmKit/lib/config_paytm.php");
			require_once(APPPATH . "/third_party/PaytmKit/lib/encdec_paytm.php");

			$request = requestJson('dts');

if( ($_SERVER['REQUEST_METHOD'] == 'POST') ){

$orderId = isset($request['orderId']) ? trim($request['orderId']) : false;
$getagentid = $this->c_model->getSingle('dmtlog', array('orderid'=>$orderId) ,' * ' );
$buffer['status'] = $getagentid['status'];


if($orderId){
$paytmParams = array(); 
$paytmParams["orderId"] = $orderId;
$post_data = json_encode($paytmParams, JSON_UNESCAPED_SLASHES);

$checksum = getChecksumFromString($post_data, PAYTM_MERCHANT_KEY ); 
$x_mid = PAYTM_MERCHANT_MID;
$x_checksum = $checksum;

$url = PAYTM_FUND_CHECKSUM_URL; 
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "x-mid: " . $x_mid, "x-checksum: " . $x_checksum)); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
$jsonresponse = curl_exec($ch);

$buffer = $jsonresponse ? json_decode( $jsonresponse, true ) : array();

/*save response data in database start script */
if(isset($buffer['status']) && ($buffer['status']=='SUCCESS') ){
   $save['banktxnid'] = $buffer['result']['paytmOrderId'];
   $save['status'] = 'SUCCESS';
   $save['transctionid'] = $buffer['result']['mid'];
   $save['respmsg'] = $buffer['statusMessage'];
   $save['ptm_comision'] = $buffer['result']['commissionAmount'];
   $save['ptm_tax'] = $buffer['result']['tax'];
   $save['ptm_rrn'] = $buffer['result']['rrn'];
   $this->c_model->saveupdate('dmtlog',$save,null,array('orderid'=>$orderId));
}
/*save response data in database end script */



/*save response data in database start script */
if(isset($buffer['status']) && ( ($buffer['status']=='FAILURE') || ($buffer['status']=='PENDING' && $buffer['statusCode']=='DE_102' ) ) ){
   $save['banktxnid'] = isset($buffer['result']['paytmOrderId'])?$buffer['result']['paytmOrderId']:'';
   $save['status'] = 'FAILURE';
   $save['transctionid'] = isset($buffer['result']['mid'])?$buffer['result']['mid']:'';
   $save['respmsg'] = isset($buffer['statusMessage'])?$buffer['statusMessage']:'';
   $save['ptm_comision'] = isset($buffer['result']['commissionAmount'])?$buffer['result']['commissionAmount']:'';
   $save['ptm_tax'] = isset($buffer['result']['tax'])?$buffer['result']['tax']:'';
   $save['ptm_rrn'] = isset($buffer['result']['rrn'])?$buffer['result']['rrn']:'';
   $this->c_model->saveupdate('dmtlog',$save,null,array('orderid'=>$orderId));

   /*return amount to agent wallet*/ 
   $getaddby = $this->c_model->getSingle('users',array('id'=>$getagentid['userid']),'uniqueid,user_type');
   $comments = 'Money Refund';
				$wtsave['userid'] = $getagentid['userid'];
				$wtsave['usertype'] = $getagentid['usertype'];
				$wtsave['uniqueid'] = trim($getaddby['uniqueid']);  
				$wtsave['paymode'] = 'wallet';
				$wtsave['transctionid'] = $orderId;
				$wtsave['credit_debit'] = 'credit';
				$wtsave['upiid'] = '';
				$wtsave['bankname'] = ''; 
				$wtsave['remark'] = 'Return against money transfer for orderid '.$getagentid['sys_orderid'].' | '.$orderId;
				$wtsave['status'] = 'success'; 
				$wtsave['amount'] = $getagentid['amount'];
				$wtsave['subject'] = str_replace(' ', '_', strtolower($comments)) ;
				$wtsave['addby'] = $getagentid['userid'];
				$wtsave['orderid'] = $getagentid['sys_orderid'];
				$walleturl = ADMINURL.('webapi/wallet/Creditdebit');
				$waltwhere['dts'] = $wtsave;  
				$headerwt = array('auth: Access-Token='.WALLETOKEN ); 
				$upwt = curlApis($walleturl,'POST', $waltwhere,$headerwt ); 
   /*return amount to agent wallet*/
}
/*save response data in database end script */


		if(isset($buffer['status']) && ($buffer['status']) ){
		$response['status'] = true;
		$response['data'] = $buffer ;
		$response['message'] = isset($buffer['statusMessage'])?$buffer['statusMessage']:'Success!';
		}else{
		$response['status'] = false;
		$response['message'] = isset($buffer['statusMessage'])?$buffer['statusMessage']:'Paytm error!';
		}


}else{
	$response['status'] = false;
	$response['message'] = 'Order Id is blank!';
}



}else{
	$response['status'] = false;
	$response['message'] = 'Bad Request!';
}

header('Content-Type:application/json');
echo json_encode($response);
} 

	
}
?>